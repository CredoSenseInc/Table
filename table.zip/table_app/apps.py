from django.apps import AppConfig


class TableAppConfig(AppConfig):
    name = 'table_app'
